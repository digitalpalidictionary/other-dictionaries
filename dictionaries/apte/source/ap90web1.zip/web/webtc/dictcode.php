<?php
$dictcode = "ap90";
$dictwebversion = "02.004";
?>
